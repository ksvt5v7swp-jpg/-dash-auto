package com.dash.auto;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import org.json.JSONArray;
import org.json.JSONObject;

public class TripService extends Service {
    private LocationManager lm;
    private Location last;

    private final LocationListener ll = new LocationListener() {
        public void onLocationChanged(Location l) {
            if (last != null && l.getAccuracy() <= 50f) {
                float d = last.distanceTo(l);
                float kmh = l.hasSpeed() ? l.getSpeed() * 3.6f : 0f;
                if (kmh >= 3f && d < 500f) {
                    SharedPreferences sp = getSharedPreferences("dash", MODE_PRIVATE);
                    track(sp, d, kmh);
                }
            }
            if (l.getAccuracy() <= 50f && l.hasSpeed() && l.getSpeed() * 3.6f >= 3f) {
                getSharedPreferences("dash", MODE_PRIVATE).edit()
                    .putString("park_lat", Double.toString(l.getLatitude()))
                    .putString("park_lon", Double.toString(l.getLongitude()))
                    .putLong("park_t", System.currentTimeMillis()).apply();
            }
            last = l;
        }
        public void onStatusChanged(String s, int i, Bundle b) { }
        public void onProviderEnabled(String s) { }
        public void onProviderDisabled(String s) { }
    };

    private void track(SharedPreferences sp, float d, float kmh) {
        long now = System.currentTimeMillis();
        long dm = Math.round(d * 10f);
        SharedPreferences.Editor ed = sp.edit();
        long tStart = sp.getLong("t_start", 0L);
        long tLast = sp.getLong("t_last", 0L);
        long dist = sp.getLong("t_dist_dm", 0L);
        float vmax = sp.getFloat("t_vmax", 0f);
        if (tStart != 0L && now - tLast >= 300000L) {
            try {
                JSONArray a = new JSONArray(sp.getString("trips", "[]"));
                JSONObject o = new JSONObject();
                o.put("s", tStart);
                o.put("e", tLast);
                o.put("d", dist / 10.0);
                o.put("v", (double) vmax);
                a.put(o);
                while (a.length() > 300) a.remove(0);
                ed.putString("trips", a.toString());
            } catch (Exception e) { }
            tStart = 0L;
        }
        if (tStart == 0L) { tStart = now; dist = 0L; vmax = 0f; }
        dist += dm;
        if (kmh > vmax && kmh < 250f) vmax = kmh;
        ed.putLong("odo_dm", sp.getLong("odo_dm", 0L) + dm);
        ed.putLong("t_start", tStart).putLong("t_last", now).putLong("t_dist_dm", dist).putFloat("t_vmax", vmax);
        ed.apply();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            Notification n;
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel("trip", "Kilométrage", NotificationManager.IMPORTANCE_LOW);
                ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
                n = new Notification.Builder(this, "trip")
                    .setContentTitle("Dash Auto")
                    .setContentText("Suivi du kilométrage")
                    .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                    .build();
            } else {
                n = new Notification.Builder(this)
                    .setContentTitle("Dash Auto")
                    .setContentText("Suivi du kilométrage")
                    .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                    .build();
            }
            startForeground(1, n);
            lm = (LocationManager) getSystemService(LOCATION_SERVICE);
            lm.removeUpdates(ll);
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 0, ll);
        } catch (Exception e) {
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        try { if (lm != null) lm.removeUpdates(ll); } catch (Exception e) { }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent i) { return null; }
}
