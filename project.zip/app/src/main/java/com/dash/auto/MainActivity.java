package com.dash.auto;

import android.Manifest;
import android.app.Activity;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {
    private WebView web;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.setBackgroundColor(0xFF030814);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        hideBars();
    }

    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @Override
    public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) hideBars();
    }

    @Override
    public void onBackPressed() { }

    private LocationManager lm;
    private final LocationListener ll = new LocationListener() {
        public void onLocationChanged(Location l) {
            float kmh = l.hasSpeed() ? l.getSpeed() * 3.6f : 0f;
            if (kmh < 2f) kmh = 0f;
            web.evaluateJavascript("setSpeed(" + kmh + ")", null);
        }
        public void onStatusChanged(String s, int i, Bundle b) { }
        public void onProviderEnabled(String s) { }
        public void onProviderDisabled(String s) { }
    };

    private void startGps() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        }
        try {
            lm = (LocationManager) getSystemService(LOCATION_SERVICE);
            lm.removeUpdates(ll);
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, ll);
        } catch (Exception e) { }
    }

    @Override
    protected void onResume() { super.onResume(); startGps(); }

    @Override
    protected void onPause() {
        super.onPause();
        try { if (lm != null) lm.removeUpdates(ll); } catch (Exception e) { }
    }

    @Override
    public void onRequestPermissionsResult(int c, String[] p, int[] r) {
        if (r.length > 0 && r[0] == PackageManager.PERMISSION_GRANTED) startGps();
    }

    class Bridge {
        @JavascriptInterface
        public void open(final String what) {
            runOnUiThread(new Runnable() { public void run() { launch(what); } });
        }

        @JavascriptInterface
        public String apps() {
            try {
                PackageManager pm = getPackageManager();
                Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> l = pm.queryIntentActivities(q, 0);
                List<JSONObject> out = new ArrayList<JSONObject>();
                for (ResolveInfo r : l) {
                    String pkg = r.activityInfo.packageName;
                    if (pkg.equals(getPackageName())) continue;
                    JSONObject o = new JSONObject();
                    o.put("n", r.loadLabel(pm).toString());
                    o.put("p", pkg);
                    o.put("i", icon(r.loadIcon(pm)));
                    out.add(o);
                }
                Collections.sort(out, new java.util.Comparator<JSONObject>() {
                    public int compare(JSONObject a, JSONObject b) {
                        return a.optString("n").compareToIgnoreCase(b.optString("n"));
                    }
                });
                return new JSONArray(out).toString();
            } catch (Exception e) {
                return "[]";
            }
        }
    }

    private String icon(Drawable d) {
        Bitmap bm = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        d.setBounds(0, 0, 96, 96);
        d.draw(c);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.PNG, 90, bo);
        return Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
    }

    private void launch(String what) {
        try {
            Intent i;
            if (what.startsWith("pkg:")) {
                i = getPackageManager().getLaunchIntentForPackage(what.substring(4));
            } else if (what.equals("tel")) {
                i = new Intent(Intent.ACTION_DIAL);
            } else if (what.equals("mus")) {
                i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC);
            } else if (what.equals("nav")) {
                i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MAPS);
            } else if (what.equals("set")) {
                i = new Intent(Settings.ACTION_SETTINGS);
            } else {
                return;
            }
            if (i == null) throw new Exception("none");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Aucune application trouvée", Toast.LENGTH_SHORT).show();
        }
    }
}
