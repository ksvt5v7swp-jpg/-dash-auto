package com.dash.auto;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.os.Handler;
import android.os.Looper;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.ProviderInfo;
import android.content.pm.ServiceInfo;
import android.database.Cursor;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.regex.Pattern;
import android.content.SharedPreferences;
import android.net.Uri;
import android.media.AudioManager;
import android.view.KeyEvent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {
    private static boolean autoDone = false;
    private WebView web;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.setBackgroundColor(0xFF030814);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        if (!autoDone) {
            autoDone = true;
            if (getSharedPreferences("dash", MODE_PRIVATE).getBoolean("auto_zlink", true)) {
                web.postDelayed(new Runnable() { public void run() {
                    Intent zi = findApp("zlink");
                    if (zi != null) {
                        zi.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        try { startActivity(zi); } catch (Exception e) { }
                    }
                } }, 4000);
            }
        }
        hideBars();
    }

    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @Override
    public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) hideBars();
    }

    @Override
    public void onBackPressed() { }

    private LocationManager lm;
    private final LocationListener ll = new LocationListener() {
        public void onLocationChanged(Location l) {
            float kmh = l.hasSpeed() ? l.getSpeed() * 3.6f : 0f;
            if (kmh < 2f) kmh = 0f;
            web.evaluateJavascript("setSpeed(" + kmh + "," + l.getLatitude() + "," + l.getLongitude() + ")", null);
        }
        public void onStatusChanged(String s, int i, Bundle b) { }
        public void onProviderEnabled(String s) { }
        public void onProviderDisabled(String s) { }
    };

    private void startGps() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        }
        try {
            lm = (LocationManager) getSystemService(LOCATION_SERVICE);
            lm.removeUpdates(ll);
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, ll);
            Intent si = new Intent(this, TripService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(si); else startService(si);
        } catch (Exception e) { }
    }

    @Override
    protected void onResume() { super.onResume(); startGps(); mh.removeCallbacks(mediaPoll); mh.post(mediaPoll); }

    @Override
    protected void onPause() {
        super.onPause();
        mh.removeCallbacks(mediaPoll);
        try { if (lm != null) lm.removeUpdates(ll); } catch (Exception e) { }
    }

    @Override
    public void onRequestPermissionsResult(int c, String[] p, int[] r) {
        if (r.length > 0 && r[0] == PackageManager.PERMISSION_GRANTED) startGps();
    }

    private List<String> sh(String cmd) {
        List<String> r = new ArrayList<String>();
        try {
            Process pr = Runtime.getRuntime().exec(new String[]{"sh", "-c", cmd});
            BufferedReader br = new BufferedReader(new InputStreamReader(pr.getInputStream()));
            String l;
            while ((l = br.readLine()) != null && r.size() < 3000) r.add(l);
            br.close();
        } catch (Exception e) { r.add("(erreur: " + e.getMessage() + ")"); }
        return r;
    }

    private List<String> diag() {
        List<String> L = new ArrayList<String>();
        PackageManager pm = getPackageManager();
        L.add("== APPAREIL ==");
        L.add(Build.MANUFACTURER + " " + Build.MODEL + " | " + Build.BOARD + " | " + Build.HARDWARE);
        L.add("Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")");
        L.add(Build.DISPLAY);
        L.add("== PROPRIETES SYSTEME LIEES AU CAN ==");
        Pattern p = Pattern.compile("(?i)(\\bcan\\b|can_|_can|canbox|canbus|\\bcar\\b|carinfo|car_|_car|mcu|syu|fyt|raise|hct|txz|nwd|dasaita|joying|zlink|carplay|vehicle|uart)");
        int n = 0;
        for (String l : sh("getprop")) { if (n < 16 && p.matcher(l).find()) { L.add(l); n++; } }
        if (n == 0) L.add("(aucune)");
        L.add("== APPLIS LIEES AU CAN / VOITURE ==");
        List<PackageInfo> hits = new ArrayList<PackageInfo>();
        try {
            for (ApplicationInfo ai : pm.getInstalledApplications(0)) {
                String pkg = ai.packageName;
                if (pkg.equals(getPackageName())) continue;
                String lab = String.valueOf(pm.getApplicationLabel(ai));
                if (hits.size() < 16 && p.matcher(pkg + " " + lab).find()) {
                    boolean sys = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                    L.add(lab + " (" + pkg + ")" + (sys ? " [sys]" : ""));
                    try {
                        hits.add(pm.getPackageInfo(pkg, PackageManager.GET_SERVICES | PackageManager.GET_PROVIDERS | PackageManager.GET_RECEIVERS));
                    } catch (Exception e) { }
                }
            }
        } catch (Exception e) { L.add("Erreur: " + e.getMessage()); }
        if (hits.isEmpty()) L.add("(aucune)");
        L.add("== SERVICES ET FOURNISSEURS EXPOSES ==");
        List<String> auths = new ArrayList<String>();
        int shown = 0;
        for (PackageInfo pi : hits) {
            StringBuilder sb = new StringBuilder();
            int sv = 0;
            if (pi.services != null) {
                for (ServiceInfo s : pi.services) {
                    if (s.exported && sv < 4) { sb.append(s.name.replace(pi.packageName, "")).append(' '); sv++; }
                }
            }
            int pv = 0;
            if (pi.providers != null) {
                for (ProviderInfo pr : pi.providers) {
                    if (pr.exported && pr.authority != null) {
                        if (pr.readPermission == null && auths.size() < 8) auths.add(pr.authority.split(";")[0]);
                        if (pv < 3) { sb.append("[P:").append(pr.authority).append("] "); pv++; }
                    }
                }
            }
            int rc = 0;
            if (pi.receivers != null) { for (ActivityInfo ra : pi.receivers) { if (ra.exported) rc++; } }
            if (shown < 12) { L.add(pi.packageName + " : svc " + sb + "| recv " + rc); shown++; }
        }
        L.add("== TEST FOURNISSEURS (lecture seule) ==");
        for (String au : auths) {
            String r;
            try {
                Cursor c = getContentResolver().query(Uri.parse("content://" + au), null, null, null, null);
                if (c == null) { r = "null"; }
                else { r = c.getCount() + " lignes, colonnes: " + java.util.Arrays.toString(c.getColumnNames()); c.close(); }
            } catch (Exception e) { r = e.getClass().getSimpleName(); }
            L.add(au + " -> " + r);
        }
        if (auths.isEmpty()) L.add("(aucun fournisseur ouvert)");
        L.add("== PORTS /dev ==");
        Pattern d = Pattern.compile("(?i)(tty|can|mcu|spi|uart|hidraw)");
        int k = 0;
        for (String l : sh("ls -l /dev 2>/dev/null")) { if (k < 14 && d.matcher(l).find()) { L.add(l.trim()); k++; } }
        List<String> out = new ArrayList<String>();
        for (String l : L) out.add(l.length() > 150 ? l.substring(0, 150) : l);
        return out;
    }

    private final Handler mh = new Handler(Looper.getMainLooper());
    private String lastMedia = null;
    private String artKey = "";
    private String artVal = "";
    private final Runnable mediaPoll = new Runnable() {
        public void run() { pollMedia(); mh.postDelayed(this, 2000); }
    };

    private MediaController pickController() {
        MediaSessionManager msm = (MediaSessionManager) getSystemService(MEDIA_SESSION_SERVICE);
        List<MediaController> l = msm.getActiveSessions(new ComponentName(this, MediaListener.class));
        MediaController first = null;
        for (MediaController c : l) {
            if (first == null) first = c;
            PlaybackState ps = c.getPlaybackState();
            if (ps != null && ps.getState() == PlaybackState.STATE_PLAYING) return c;
        }
        return first;
    }

    private String mstr(MediaMetadata md, String key) {
        if (md == null) return "";
        String v = md.getString(key);
        return v == null ? "" : v;
    }

    private String artUri(Bitmap b) {
        if (b == null) return "";
        int w = b.getWidth(), h = b.getHeight(), m = Math.max(w, h);
        if (m > 256) {
            float s = 256f / m;
            b = Bitmap.createScaledBitmap(b, Math.max(1, (int) (w * s)), Math.max(1, (int) (h * s)), true);
        }
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.JPEG, 80, bo);
        return "data:image/jpeg;base64," + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
    }

    private void pollMedia() {
        String json;
        try {
            MediaController c = pickController();
            if (c == null) {
                json = "{\"s\":\"none\"}";
            } else {
                MediaMetadata md = c.getMetadata();
                PlaybackState ps = c.getPlaybackState();
                boolean pl = ps != null && ps.getState() == PlaybackState.STATE_PLAYING;
                String t = mstr(md, MediaMetadata.METADATA_KEY_TITLE);
                String ar = mstr(md, MediaMetadata.METADATA_KEY_ARTIST);
                Bitmap bm = null;
                if (md != null) {
                    bm = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
                    if (bm == null) bm = md.getBitmap(MediaMetadata.METADATA_KEY_ART);
                    if (bm == null) bm = md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON);
                }
                String key = t + "|" + ar;
                if (!key.equals(artKey) || (artVal.length() == 0 && bm != null)) {
                    artKey = key;
                    artVal = artUri(bm);
                }
                JSONObject o = new JSONObject();
                o.put("s", "ok");
                o.put("t", t);
                o.put("a", ar);
                o.put("p", pl);
                o.put("i", artVal);
                json = o.toString();
            }
        } catch (SecurityException e) {
            json = "{\"s\":\"noaccess\"}";
        } catch (Exception e) {
            json = "{\"s\":\"none\"}";
        }
        if (!json.equals(lastMedia)) {
            lastMedia = json;
            web.evaluateJavascript("onMedia(" + json + ")", null);
        }
    }

    class Bridge {
        @JavascriptInterface
        public void mediaReady() { lastMedia = null; }

        @JavascriptInterface
        public void openNotifAccess() {
            runOnUiThread(new Runnable() { public void run() {
                try {
                    Intent i = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Réglages introuvables : active l’accès aux notifications pour Dash Auto", Toast.LENGTH_LONG).show();
                }
            } });
        }

        @JavascriptInterface
        public void loadDiag() {
            new Thread(new Runnable() { public void run() {
                final String json = new JSONArray(diag()).toString();
                runOnUiThread(new Runnable() { public void run() {
                    web.evaluateJavascript("onDiag(" + json + ")", null);
                } });
            } }).start();
        }

        @JavascriptInterface
        public String trips() {
            SharedPreferences sp = getSharedPreferences("dash", MODE_PRIVATE);
            String list = sp.getString("trips", "[]");
            long ts = sp.getLong("t_start", 0L);
            if (ts != 0L) {
                try {
                    JSONArray a = new JSONArray(list);
                    JSONObject o = new JSONObject();
                    o.put("s", ts);
                    o.put("e", sp.getLong("t_last", ts));
                    o.put("d", sp.getLong("t_dist_dm", 0L) / 10.0);
                    o.put("v", (double) sp.getFloat("t_vmax", 0f));
                    a.put(o);
                    return a.toString();
                } catch (Exception e) { }
            }
            return list;
        }

        @JavascriptInterface
        public void clearTrips() {
            getSharedPreferences("dash", MODE_PRIVATE).edit()
                .remove("trips").remove("t_start").remove("t_last").remove("t_dist_dm").remove("t_vmax").apply();
        }

        @JavascriptInterface
        public boolean autoZlink() {
            return getSharedPreferences("dash", MODE_PRIVATE).getBoolean("auto_zlink", true);
        }

        @JavascriptInterface
        public void setAutoZlink(boolean b) {
            getSharedPreferences("dash", MODE_PRIVATE).edit().putBoolean("auto_zlink", b).apply();
        }

        @JavascriptInterface
        public String park() {
            SharedPreferences sp = getSharedPreferences("dash", MODE_PRIVATE);
            String lat = sp.getString("park_lat", null);
            if (lat == null) return "";
            return "{\"lat\":\"" + lat + "\",\"lon\":\"" + sp.getString("park_lon", "") + "\",\"t\":" + sp.getLong("park_t", 0L) + "}";
        }

        @JavascriptInterface
        public void loadApps() {
            new Thread(new Runnable() { public void run() {
                final String json = apps();
                runOnUiThread(new Runnable() { public void run() {
                    web.evaluateJavascript("onApps(" + json + ")", null);
                } });
            } }).start();
        }

        @JavascriptInterface
        public void media(final String k) {
            runOnUiThread(new Runnable() { public void run() {
                try {
                    MediaController mc = pickController();
                    if (mc != null) {
                        MediaController.TransportControls tc = mc.getTransportControls();
                        if (k.equals("prev")) tc.skipToPrevious();
                        else if (k.equals("next")) tc.skipToNext();
                        else {
                            PlaybackState ps = mc.getPlaybackState();
                            if (ps != null && ps.getState() == PlaybackState.STATE_PLAYING) tc.pause(); else tc.play();
                        }
                        return;
                    }
                } catch (Exception e) { }
                int code = k.equals("prev") ? KeyEvent.KEYCODE_MEDIA_PREVIOUS
                         : k.equals("next") ? KeyEvent.KEYCODE_MEDIA_NEXT
                         : KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE;
                AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
                am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, code));
                am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, code));
            } });
        }

        @JavascriptInterface
        public String odo() {
            return String.valueOf(getSharedPreferences("dash", MODE_PRIVATE).getLong("odo_dm", 0L) / 10.0);
        }

        @JavascriptInterface
        public void open(final String what) {
            runOnUiThread(new Runnable() { public void run() { launch(what); } });
        }

        @JavascriptInterface
        public String apps() {
            try {
                PackageManager pm = getPackageManager();
                Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> l = pm.queryIntentActivities(q, 0);
                List<JSONObject> out = new ArrayList<JSONObject>();
                for (ResolveInfo r : l) {
                    String pkg = r.activityInfo.packageName;
                    if (pkg.equals(getPackageName())) continue;
                    JSONObject o = new JSONObject();
                    o.put("n", r.loadLabel(pm).toString());
                    o.put("p", pkg);
                    o.put("i", icon(r.loadIcon(pm)));
                    out.add(o);
                }
                Collections.sort(out, new java.util.Comparator<JSONObject>() {
                    public int compare(JSONObject a, JSONObject b) {
                        return a.optString("n").compareToIgnoreCase(b.optString("n"));
                    }
                });
                return new JSONArray(out).toString();
            } catch (Exception e) {
                return "[]";
            }
        }
    }

    private String icon(Drawable d) {
        Bitmap bm = Bitmap.createBitmap(72, 72, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        d.setBounds(0, 0, 72, 72);
        d.draw(c);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.PNG, 90, bo);
        return Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
    }

    private Intent findApp(String needle) {
        PackageManager pm = getPackageManager();
        Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        for (ResolveInfo r : pm.queryIntentActivities(q, 0)) {
            String n = r.loadLabel(pm).toString().toLowerCase();
            if (n.contains(needle)) return pm.getLaunchIntentForPackage(r.activityInfo.packageName);
        }
        return null;
    }

    private void launch(String what) {
        try {
            Intent i;
            if (what.startsWith("pkg:")) {
                i = getPackageManager().getLaunchIntentForPackage(what.substring(4));
            } else if (what.equals("tel")) {
                i = new Intent(Intent.ACTION_DIAL);
            } else if (what.equals("mus")) {
                i = findApp("zlink");
            } else if (what.equals("nav")) {
                i = getPackageManager().getLaunchIntentForPackage("com.waze");
                if (i == null) i = findApp("waze");
            } else if (what.equals("parknav") || what.equals("parkshare")) {
                SharedPreferences sp = getSharedPreferences("dash", MODE_PRIVATE);
                String lat = sp.getString("park_lat", null);
                String lon = sp.getString("park_lon", null);
                if (lat == null || lon == null) {
                    Toast.makeText(this, "Aucune position enregistrée", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (what.equals("parknav")) {
                    i = new Intent(Intent.ACTION_VIEW, Uri.parse("waze://?ll=" + lat + "," + lon + "&navigate=yes"));
                } else {
                    i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, "Ma voiture est ici : https://maps.google.com/?q=" + lat + "," + lon);
                    i = Intent.createChooser(i, "Partager la position");
                }
            } else if (what.equals("set")) {
                i = new Intent(Settings.ACTION_SETTINGS);
            } else {
                return;
            }
            if (i == null) throw new Exception("none");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Application introuvable : vérifie qu'elle est installée", Toast.LENGTH_SHORT).show();
        }
    }
}
