package com.dash.auto;

import android.Manifest;
import android.app.Activity;
import android.content.SharedPreferences;
import android.net.Uri;
import android.media.AudioManager;
import android.view.KeyEvent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {
    private static boolean autoDone = false;
    private WebView web;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.setBackgroundColor(0xFF030814);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        if (!autoDone) {
            autoDone = true;
            if (getSharedPreferences("dash", MODE_PRIVATE).getBoolean("auto_zlink", true)) {
                web.postDelayed(new Runnable() { public void run() {
                    Intent zi = findApp("zlink");
                    if (zi != null) {
                        zi.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        try { startActivity(zi); } catch (Exception e) { }
                    }
                } }, 4000);
            }
        }
        hideBars();
    }

    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @Override
    public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) hideBars();
    }

    @Override
    public void onBackPressed() { }

    private LocationManager lm;
    private final LocationListener ll = new LocationListener() {
        public void onLocationChanged(Location l) {
            float kmh = l.hasSpeed() ? l.getSpeed() * 3.6f : 0f;
            if (kmh < 2f) kmh = 0f;
            web.evaluateJavascript("setSpeed(" + kmh + "," + l.getLatitude() + "," + l.getLongitude() + ")", null);
        }
        public void onStatusChanged(String s, int i, Bundle b) { }
        public void onProviderEnabled(String s) { }
        public void onProviderDisabled(String s) { }
    };

    private void startGps() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        }
        try {
            lm = (LocationManager) getSystemService(LOCATION_SERVICE);
            lm.removeUpdates(ll);
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, ll);
            Intent si = new Intent(this, TripService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(si); else startService(si);
        } catch (Exception e) { }
    }

    @Override
    protected void onResume() { super.onResume(); startGps(); }

    @Override
    protected void onPause() {
        super.onPause();
        try { if (lm != null) lm.removeUpdates(ll); } catch (Exception e) { }
    }

    @Override
    public void onRequestPermissionsResult(int c, String[] p, int[] r) {
        if (r.length > 0 && r[0] == PackageManager.PERMISSION_GRANTED) startGps();
    }

    class Bridge {
        @JavascriptInterface
        public String trips() {
            SharedPreferences sp = getSharedPreferences("dash", MODE_PRIVATE);
            String list = sp.getString("trips", "[]");
            long ts = sp.getLong("t_start", 0L);
            if (ts != 0L) {
                try {
                    JSONArray a = new JSONArray(list);
                    JSONObject o = new JSONObject();
                    o.put("s", ts);
                    o.put("e", sp.getLong("t_last", ts));
                    o.put("d", sp.getLong("t_dist_dm", 0L) / 10.0);
                    o.put("v", (double) sp.getFloat("t_vmax", 0f));
                    a.put(o);
                    return a.toString();
                } catch (Exception e) { }
            }
            return list;
        }

        @JavascriptInterface
        public void clearTrips() {
            getSharedPreferences("dash", MODE_PRIVATE).edit()
                .remove("trips").remove("t_start").remove("t_last").remove("t_dist_dm").remove("t_vmax").apply();
        }

        @JavascriptInterface
        public boolean autoZlink() {
            return getSharedPreferences("dash", MODE_PRIVATE).getBoolean("auto_zlink", true);
        }

        @JavascriptInterface
        public void setAutoZlink(boolean b) {
            getSharedPreferences("dash", MODE_PRIVATE).edit().putBoolean("auto_zlink", b).apply();
        }

        @JavascriptInterface
        public String park() {
            SharedPreferences sp = getSharedPreferences("dash", MODE_PRIVATE);
            String lat = sp.getString("park_lat", null);
            if (lat == null) return "";
            return "{\"lat\":\"" + lat + "\",\"lon\":\"" + sp.getString("park_lon", "") + "\",\"t\":" + sp.getLong("park_t", 0L) + "}";
        }

        @JavascriptInterface
        public void loadApps() {
            new Thread(new Runnable() { public void run() {
                final String json = apps();
                runOnUiThread(new Runnable() { public void run() {
                    web.evaluateJavascript("onApps(" + json + ")", null);
                } });
            } }).start();
        }

        @JavascriptInterface
        public void media(final String k) {
            runOnUiThread(new Runnable() { public void run() {
                int code = k.equals("prev") ? KeyEvent.KEYCODE_MEDIA_PREVIOUS
                         : k.equals("next") ? KeyEvent.KEYCODE_MEDIA_NEXT
                         : KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE;
                AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
                am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, code));
                am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, code));
            } });
        }

        @JavascriptInterface
        public String odo() {
            return String.valueOf(getSharedPreferences("dash", MODE_PRIVATE).getLong("odo_dm", 0L) / 10.0);
        }

        @JavascriptInterface
        public void open(final String what) {
            runOnUiThread(new Runnable() { public void run() { launch(what); } });
        }

        @JavascriptInterface
        public String apps() {
            try {
                PackageManager pm = getPackageManager();
                Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> l = pm.queryIntentActivities(q, 0);
                List<JSONObject> out = new ArrayList<JSONObject>();
                for (ResolveInfo r : l) {
                    String pkg = r.activityInfo.packageName;
                    if (pkg.equals(getPackageName())) continue;
                    JSONObject o = new JSONObject();
                    o.put("n", r.loadLabel(pm).toString());
                    o.put("p", pkg);
                    o.put("i", icon(r.loadIcon(pm)));
                    out.add(o);
                }
                Collections.sort(out, new java.util.Comparator<JSONObject>() {
                    public int compare(JSONObject a, JSONObject b) {
                        return a.optString("n").compareToIgnoreCase(b.optString("n"));
                    }
                });
                return new JSONArray(out).toString();
            } catch (Exception e) {
                return "[]";
            }
        }
    }

    private String icon(Drawable d) {
        Bitmap bm = Bitmap.createBitmap(72, 72, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        d.setBounds(0, 0, 72, 72);
        d.draw(c);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.PNG, 90, bo);
        return Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
    }

    private Intent findApp(String needle) {
        PackageManager pm = getPackageManager();
        Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        for (ResolveInfo r : pm.queryIntentActivities(q, 0)) {
            String n = r.loadLabel(pm).toString().toLowerCase();
            if (n.contains(needle)) return pm.getLaunchIntentForPackage(r.activityInfo.packageName);
        }
        return null;
    }

    private void launch(String what) {
        try {
            Intent i;
            if (what.startsWith("pkg:")) {
                i = getPackageManager().getLaunchIntentForPackage(what.substring(4));
            } else if (what.equals("tel")) {
                i = new Intent(Intent.ACTION_DIAL);
            } else if (what.equals("mus")) {
                i = findApp("zlink");
            } else if (what.equals("nav")) {
                i = getPackageManager().getLaunchIntentForPackage("com.waze");
                if (i == null) i = findApp("waze");
            } else if (what.equals("parknav") || what.equals("parkshare")) {
                SharedPreferences sp = getSharedPreferences("dash", MODE_PRIVATE);
                String lat = sp.getString("park_lat", null);
                String lon = sp.getString("park_lon", null);
                if (lat == null || lon == null) {
                    Toast.makeText(this, "Aucune position enregistrée", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (what.equals("parknav")) {
                    i = new Intent(Intent.ACTION_VIEW, Uri.parse("waze://?ll=" + lat + "," + lon + "&navigate=yes"));
                } else {
                    i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, "Ma voiture est ici : https://maps.google.com/?q=" + lat + "," + lon);
                    i = Intent.createChooser(i, "Partager la position");
                }
            } else if (what.equals("set")) {
                i = new Intent(Settings.ACTION_SETTINGS);
            } else {
                return;
            }
            if (i == null) throw new Exception("none");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Application introuvable : vérifie qu'elle est installée", Toast.LENGTH_SHORT).show();
        }
    }
}
